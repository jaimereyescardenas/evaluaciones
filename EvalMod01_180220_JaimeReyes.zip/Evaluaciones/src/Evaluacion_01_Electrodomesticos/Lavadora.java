package Evaluacion_01_Electrodomesticos;

//Lavadora es subclase de Electrodom�stico
public class Lavadora extends Electrodom�stico{ 
	
	/* Definici�n de las constantes de clase, con los valores por defecto. */
	private static final int CARGA_DEFECTO = 5;
	
	//Definici�n del atributo de clase carga, con su valor por defecto.
	private int carga = CARGA_DEFECTO;
	
	/* Constructor por defecto, que crear� los objetos con todos sus atributos 
	 * (el propio y los heredados de la clase padre) con sus valores 
	 * por defecto. */
	public Lavadora() {
		super();
	}
	
	/* Constructor con los par�metros precio base y peso, los dem�s atributos 
	 * (el propio y los heredados) quedan con sus valores por defecto. */
	public Lavadora(int precioBase, int peso) {
		
		super(precioBase, peso);
		
	}
	
	/* Constructor con todos los par�metros (propios y heredados) definidos. 
	 * No generar� valores por defecto a menos que el color o la letra 
	 * del consumo energ�tico ingresados no coincidan con alg�n valor 
	 * dentro de los posibles (los que est�n definidos en los arreglos
	 * de constantes de la clase padre). */
	public Lavadora(int precioBase, String color, char consumoEnerg�tico,
													int peso, int carga) {
		
		super(precioBase, color, consumoEnerg�tico, peso);
		this.carga = carga;
		
	}
	
	//M�todo get del �nico atributo propio
	public int getCarga() {
		return carga;
	}
	
	/* Calcula el precio final de una lavadora seg�n su precio base, 
	 * su consumo energ�tico, su peso y su capacidad de carga, comprobando 
	 * distintos rangos. Utiliza el m�todo precioFinal() de la clase padre. 
	 * Entrega el valor del precio final para ser usado en otros m�todos 
	 * o para ser presentado. */
	@Override
	public int precioFinal() {
		
		int precio = super.precioFinal();
		
		if (getCarga() > 30) {
			
			precio += 40000;
			
		}
		
		return precio;
		
	}

}
