package Evaluacion_01_Electrodomesticos;

public class Electrodom�stico {
	/* Definici�n de las constantes de clase, con los valores por defecto.
	 * Se incluyen dos arreglos con los valores aceptados 
	 * para el color y la letra del consumo energ�tico. */
	protected static final int PRECIO_DEFECTO = 100000;
	protected static final String COLOR_DEFECTO = "blanco";
	protected static final char CONSUMO_DEFECTO = 'F';
	protected static final int PESO_DEFECTO = 5;
	private static final char[] CONSUMO_ENERGETICO = {'A', 'B', 'C', 'D',
													  			'E', 'F'}; 
	private static final String[] COLORES = {"blanco", "negro", "rojo", 
											 			"azul", "gris"};
	/* Definici�n de los atributos de clase 
	 * (precio base, color, consumo energ�tico y peso).
	 * A cada atributo se le asigna el valor por defecto. */
	private int precioBase = PRECIO_DEFECTO;
	private String color = COLOR_DEFECTO;
	private char consumoEnerg�tico = CONSUMO_DEFECTO;
	private int peso = PESO_DEFECTO;
	
	/* Constructor por defecto, que crear� los objetos 
	 * con los valores por defecto. */
	public Electrodom�stico() {
		super();
	}
	
	/* Constructor con los par�metros precio base y peso, 
	 * los dem�s atributos quedan con sus valores por defecto. */
	public Electrodom�stico(int precioBase, int peso) {
		super();
		this.precioBase = precioBase;
		this.peso = peso;
	}
	
	/* Constructor con todos los par�metros definidos. 
	 * No generar� valores por defecto a menos que el color o la letra 
	 * del consumo energ�tico ingresados no coincidan con alg�n valor 
	 * dentro de los posibles (los que est�n definidos en los arreglos
	 * de constantes). */
	public Electrodom�stico(int precioBase, String color, 
							char consumoEnerg�tico, int peso) {
		super();
		this.precioBase = precioBase;
		this.color = comprobarColor(color);
		this.consumoEnerg�tico = comprobarConsumoEnerg�tico(consumoEnerg�tico);
		this.peso = peso;
	}
	//Getters para los atributos
	public int getPrecioBase() {
		return precioBase;
	}

	public String getColor() {
		return color;
	}

	public char getConsumoEnerg�tico() {
		return consumoEnerg�tico;
	}

	public int getPeso() {
		return peso;
	}
	
	/* Comprueba que la letra de consumo energ�tico ingresada al utilizar
	 * un constructor sea una v�lida de entre las posibles. Si no es as�,
	 * la reemplaza por la letra por defecto.
	 * Esta funci�n convierte previamente a may�scula la letra ingresada,
	 * luego hace la comprobaci�n, y por �ltimo entrega el valor final 
	 * (que tambi�n es may�scula). */
	private char comprobarConsumoEnerg�tico(char letra) {
		
		char consumo = CONSUMO_DEFECTO;
		char letraMayus = Character.toUpperCase(letra);
		
		for (int i = 0; i < CONSUMO_ENERGETICO.length; i++) {
			
			if (letraMayus == CONSUMO_ENERGETICO[i]) {
				
				return letraMayus;
				
			}
			
		}
		
		return consumo;
		
	}
	
	/* Comprueba que el color ingresado al utilizar un constructor sea uno
	 * v�lido de entre los posibles. Si no es as�, lo reemplaza por el color 
	 * por defecto. Esta funci�n no hace distinci�n entre may�sculas y 
	 * min�sculas, y luego entrega un resultado en min�sculas. */
	private String comprobarColor(String cadena) {
		
		String color = COLOR_DEFECTO;
		
		for (int i = 0; i < COLORES.length; i++) {
			
			if (cadena.equalsIgnoreCase(COLORES[i])) {
				
				return cadena.toLowerCase();
				
			}
			
		}
		
		return color;
		
	}
	
	/* Calcula el precio final de un electrodom�stico seg�n su precio base, 
	 * su consumo energ�tico y su peso, comprobando distintos rangos. 
	 * Entrega el valor del precio final para ser usado en otros m�todos 
	 * o para ser presentado. */
	public int precioFinal() {
		
		int precio = getPrecioBase();
		
		switch (getConsumoEnerg�tico()) {
		
		case 'A':
			
			precio += 85000;
			break;
			
		case 'B':
			
			precio += 70000;
			break;
			
		case 'C':
			
			precio += 50000;
			break;
			
		case 'D':
			
			precio += 40000;
			break;
			
		case 'E':
			
			precio += 25000;
			break;
			
		case 'F':
			
			precio += 8500;
			break;
		
		}
		
		if (getPeso() >= 0 && getPeso() <= 19) {
			
			precio += 8500;
			
		}
		
		if (getPeso() >= 20 && getPeso() <= 49) {
			
			precio += 40000;
			
		}
		
		if (getPeso() >= 50 && getPeso() <= 79) {
			
			precio += 70000;
			
		}
		
		if (getPeso() >= 80) {
			
			precio += 85000;
			
		}
		
		return precio;
		
	}

}
