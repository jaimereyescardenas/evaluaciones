package Evaluacion_01_Electrodomesticos;

//Televisi�n es subclase de Electrodom�stico
public class Televisi�n extends Electrodom�stico{
	
	/* Definici�n de las constantes de clase, con los valores por defecto. */
	protected static final int RESOLUCION_DEFECTO = 20;
	protected static final boolean SINTONIZADOR_TDT_DEFECTO = false;
	
	/*Definici�n de los atributos de clase resoluci�n y sintonizador tdt, 
	con sus valores por defecto. */
	private int resoluci�n = RESOLUCION_DEFECTO;
	private boolean sintonizador_tdt = SINTONIZADOR_TDT_DEFECTO;
	
	/* Constructor por defecto, que crear� los objetos con todos sus atributos 
	 * (el propio y los heredados de la clase padre) con sus valores 
	 * por defecto. */
	public Televisi�n() {
		super();
	}
	
	/* Constructor con los par�metros precio base y peso, los dem�s atributos 
	 * (los propios y los heredados) quedan con sus valores por defecto. */
	public Televisi�n(int precioBase, int peso) {
		
		super(precioBase, peso);
		
	}

	/* Constructor con todos los par�metros (propios y heredados) definidos. 
	 * No generar� valores por defecto a menos que el color o la letra 
	 * del consumo energ�tico ingresados no coincidan con alg�n valor 
	 * dentro de los posibles (los que est�n definidos en los arreglos
	 * de constantes de la clase padre). */
	public Televisi�n(int precioBase, String color, char consumoEnerg�tico, 
						int peso, int resoluci�n, boolean sintonizador_tdt) {
		
		super(precioBase, color, consumoEnerg�tico, peso);
		this.resoluci�n = resoluci�n;
		this.sintonizador_tdt = sintonizador_tdt;
		
	}
	
	//M�todos get para los atributos propios de la clase 
	public int getResoluci�n() {
		return resoluci�n;
	}

	public boolean isSintonizador_tdt() {
		return sintonizador_tdt;
	}
	
	/* Calcula el precio final de un televisor seg�n su precio base, 
	 * su consumo energ�tico, su peso, su resoluci�n en pulgadas y si tiene 
	 * un sintonizador TDT incorporado, comprobando distintos rangos. 
	 * Utiliza el m�todo precioFinal() de la clase padre. 
	 * Entrega el valor del precio final para ser usado en otros m�todos 
	 * o para ser presentado. */
	@Override
	public int precioFinal() {
		
		int precio = super.precioFinal();
		
		if (getResoluci�n() > 40) {
			
			precio += (int)(super.getPrecioBase() * 0.3);
			
		}
		
		if (isSintonizador_tdt()) {
			
			precio += 45000;
			
		}
		
		return precio;
		
	}
	
}
