package ej01_Biotren;

public class Tarjeta {
	
	private int numTarjeta;
	private String tipoUsuario;
	private int tarifa;
	private int saldo;
	private int diasInactivo;
	private boolean activa;
	
	public void abonoDinero(int abono) {
		
		if (abono > 0) {
			
			this.saldo = saldo + abono;
			System.out.println("Se han cargado $" + abono + " a su tarjeta. "
							   + "Su nuevo saldo es de $" + saldo + ".");
			
		}
		
		
		if (abono >= 500 && !(activa)) {
			
			activa = true;
			System.out.println("Su tarjeta ha sido reactivada exitosamente.");
			
		}
		
	}
	
	public void asignarTarifa() {
		
		if (tipoUsuario == "TNE") {
			
			tarifa = 200;
			
		} else {
			
			tarifa = 600;
			
		}
		
	}
	
	public void descuentoViaje() {
		
		if (activa) {
			
			saldo -= tarifa;
			System.out.println("Se ha realizado un viaje con un costo de $" 
							   + tarifa + ". Su nuevo saldo es de $" + saldo 
							   + ".");
			
		} else {
			
			mensajeActiva();
			
		}
		
	}
	
	public void consultarSaldo() {
		
		System.out.println("Su saldo es de $" + saldo + ".");
		
	}
	
	public void asignarActividadTarjeta() {
		
		if (diasInactivo >= 365) {
			
			activa = false;
			
		} else {
			
			activa = true;
			
		}
		
	}
	
	public boolean verificarActividad() {
		
		return activa;
		
	}
	
	public void mensajeActiva() {
		
		if (activa) {
			
			System.out.println("Su tarjeta se encuentra activa. " 
							   + "Puede usarla con normalidad por "
							   + (365 - diasInactivo) + " d�a/s m�s.");
			
		} else {
			
			System.out.println("Su tarjeta se encuentra bloqueada por " 
							   + "inactividad. Por favor, realice una recarga" 
							   + " de al menos $500 para poder reactivarla.");
			
		}
		
	}

}
