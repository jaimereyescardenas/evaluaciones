package ej04_PublicoPrivado;

public class EmpleadoPublico extends Empleado {
	
	private String municipalidad;
	private String departamento;
	
	public EmpleadoPublico(String rut, String nombre, String apellidos,
						   String direccion, int telefono, double sueldo,
						   String municipalidad, String departamento) {
		
		super(rut, nombre, apellidos, direccion, telefono, sueldo);
		this.municipalidad = municipalidad;
		this.departamento = departamento;
		
	}

	public String getMunicipalidad() {
		return municipalidad;
	}

	public void setMunicipalidad(String municipalidad) {
		this.municipalidad = municipalidad;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	@Override
	public String toString() {
		
		return super.toString() + "y trabaja en la " + getMunicipalidad() 
			   + ", en el departamento " + getDepartamento() + ".";
		
	}

}
