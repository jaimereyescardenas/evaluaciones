package ej04_PublicoPrivado;

public class EmpleadoPrivado extends Empleado {
	
	private String comuna;
	private String empresa;
	
	public EmpleadoPrivado(String rut, String nombre, String apellidos,
						   String direccion, int telefono, double sueldo,
						   String comuna, String empresa) {
		
		super(rut, nombre, apellidos, direccion, telefono, sueldo);
		this.comuna = comuna;
		this.empresa = empresa;
		
	}

	public String getComuna() {
		return comuna;
	}

	public void setComuna(String comuna) {
		this.comuna = comuna;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	
	@Override
	public String toString() {
		
		return super.toString() + "y trabaja en la " + getComuna() 
			   + ", en la empresa " + getEmpresa() + ".";
		
	}

}
