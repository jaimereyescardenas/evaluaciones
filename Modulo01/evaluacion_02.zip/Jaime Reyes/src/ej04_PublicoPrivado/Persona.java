package ej04_PublicoPrivado;

public class Persona {

	public static void main(String[] args) {
		
		EmpleadoPublico epublico = new EmpleadoPublico("15242356-6", "Fernando",
									   "Mellado Salinas", "Los Laureles 45",
									   945281947, 780000,
									   "Municipalidad de Los Alamos",
									   "Administrativo");
		EmpleadoPrivado eprivado = new EmpleadoPrivado("12345678-7", "Francisco",
									   "Risopatr�n de Lourdes", "Juan Bosco 1786",
									   976834616, 6000000, "Comuna Las Condes",
									   "Gerencia");
		
		System.out.println(epublico.toString());
		System.out.println(eprivado.toString());
		

	}

}
