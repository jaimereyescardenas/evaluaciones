package Evaluacion_01_Electrodomesticos;

public class Principal {
	
	public static void main(String[] args) {
		
		//Creaci�n del arreglo de electrodom�sticos
		Electrodom�stico[] oferta = new Electrodom�stico[10];
		
		/* Creaci�n de cada uno de los objetos y asignaci�n al arreglo,
		 * usando varios tipos de constructores. */
		oferta[0] = new Televisi�n(35000, "naranjo", 'E', 36, 25, true);
		oferta[1] = new Electrodom�stico(50000, "negro", 'c', 14);
		oferta[2] = new Electrodom�stico(10000, 58);
		oferta[3] = new Lavadora(10000, "celeste", 'H', 42, 15);
		oferta[4] = new Televisi�n();
		oferta[5] = new Lavadora(25000, 12);
		oferta[6] = new Televisi�n(28500, "gris", 'd', 10, 12, false);
		oferta[7] = new Lavadora(15000, "blanco", 'E', 86, 48);
		oferta[8] = new Electrodom�stico();
		oferta[9] = new Televisi�n(50000, "negro", 'A', 58, 45, true);
		
		/* Creaci�n de las variables auxiliares que contendr�n la suma de 
		 * cada uno de los precios finales seg�n tipo de producto 
		 * (lavadora, televisi�n o electrodom�stico). */ 
		int sumaElectro = 0;
		int sumaTele = 0;
		int sumaLavadora = 0;
		
		/* Ejecuci�n del m�todo precioFinal() para cada uno de los objetos 
		 * creados, agregando el precio final resultante a la suma acumulada 
		 * seg�n tipo de producto. */
		for (int i = 0; i < oferta.length; i++) {
			
			int precio = oferta[i].precioFinal();
			
			if (oferta[i] instanceof Electrodom�stico) {
				
				sumaElectro += precio;
				
			}
			
			if (oferta[i] instanceof Televisi�n) {
				
				sumaTele += precio;
				
			}
			
			if (oferta[i] instanceof Lavadora) {
				
				sumaLavadora += precio;
				
			}
			
		}
		
		
		//Presentaci�n por pantalla de las tres sumas obtenidas
		System.out.println("La suma del precio final de todos los "
							+ "electrodom�sticos es de $" + sumaElectro);
		System.out.println("La suma del precio final de todos los "
							+ "televisores es de $" + sumaTele);
		System.out.println("La suma del precio final de todas las "
							+ "lavadoras es de $" + sumaLavadora);
		
	}
	
}
